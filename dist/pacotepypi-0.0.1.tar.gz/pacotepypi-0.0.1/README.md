# Pacote Exemplo

Como o próprio nome já indica, este arquivo existe para que o usuário possa ler algumas informações sobre o pacote.
Proposta, dependências, funcionalidades e formas de usar o pacote são possíveis informações que podem estar aqui.