def func():
	print('Seu pacote PyPI está funcionando.')